const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("activo");
    }
  });
}, { threshold: 0.5 });

document.querySelectorAll(".observado").forEach(element => {
  observer.observe(element);
});
