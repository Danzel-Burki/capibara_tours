document.addEventListener("DOMContentLoaded", () => {
  // Elementos del modal de viajes
  const modal = document.getElementById("modalViajes");
  const modalMedia = document.getElementById("modalMediaViajes");
  const modalDescripcion = document.getElementById("modalDescripcionViajes");
  const cerrar = modal.querySelector(".cerrar");
  const anterior = modal.querySelector(".anterior");
  const siguiente = modal.querySelector(".siguiente");

  // Selección de todos los viajes
  const viajes = document.querySelectorAll(".viaje");
  let indiceActual = 0;

  // Función para mostrar un viaje específico
  function mostrarViaje(index) {
    const viaje = viajes[index];
    const img = viaje.querySelector("img");
    const video = viaje.querySelector("video");
    modalMedia.innerHTML = "";

    if (img) {
      const imgClone = img.cloneNode(true);
      modalMedia.appendChild(imgClone);
    } else if (video) {
      const videoClone = video.cloneNode(true);
      videoClone.controls = true;
      videoClone.autoplay = true;
      modalMedia.appendChild(videoClone);
    }

    modalDescripcion.textContent = viaje.querySelector(".descripcion").textContent;
    modal.style.display = "flex";
    indiceActual = index;
  }

  // Event listeners para cada viaje
  viajes.forEach((viaje, index) => {
    viaje.addEventListener("click", () => mostrarViaje(index));
  });

  // Controles del modal
  anterior.addEventListener("click", () => {
    indiceActual = (indiceActual - 1 + viajes.length) % viajes.length;
    mostrarViaje(indiceActual);
  });

  siguiente.addEventListener("click", () => {
    indiceActual = (indiceActual + 1) % viajes.length;
    mostrarViaje(indiceActual);
  });

  cerrar.addEventListener("click", () => {
    modal.style.display = "none";
    modalMedia.innerHTML = "";
  });

  window.addEventListener("click", (e) => {
    if (e.target === modal) {
      modal.style.display = "none";
      modalMedia.innerHTML = "";
    }
  });
});