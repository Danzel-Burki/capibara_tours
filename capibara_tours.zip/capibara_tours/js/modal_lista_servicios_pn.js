// Selección de elementos generales
const modal = document.getElementById('modalServicios');
const modalMedia = document.getElementById('modalMediaServicios');
const modalDescripcion = document.getElementById('modalDescripcionServicios');
const btnCerrar = document.querySelector('.cerrar');
const btnSiguiente = document.querySelector('.siguiente');
const btnAnterior = document.querySelector('.anterior');

let currentIndex = 0; 
let currentService = ""; 

// Abrir modal con la carta correcta
function abrirModal(service, index) {
  currentIndex = parseInt(index);
  currentService = service;

  const carta = document.querySelector(`.carta[data-service='${service}'][data-index='${currentIndex}'] img`);
  if (carta) {
    modalMedia.innerHTML = `<img src="${carta.src}" alt="${carta.alt}" 
      style="max-width: 90vw; max-height: 80vh; display: block; margin: 0 auto;">`;
    modalDescripcion.innerText = carta.alt;

    // Centrar el modal
    modal.style.display = 'flex';
    modal.style.alignItems = 'center';
    modal.style.justifyContent = 'center';
  }
}

// Navegar siguiente/previa dentro del mismo servicio
function siguienteCarta() {
  const total = document.querySelectorAll(`.carta[data-service='${currentService}']`).length;
  currentIndex = (currentIndex + 1) % total;
  abrirModal(currentService, currentIndex);
}

function anteriorCarta() {
  const total = document.querySelectorAll(`.carta[data-service='${currentService}']`).length;
  currentIndex = (currentIndex - 1 + total) % total;
  abrirModal(currentService, currentIndex);
}

// Conectar listas (provincial + internacional)
document.querySelectorAll('.lista-turismo').forEach(lista => {
  const service = lista.getAttribute('data-service'); 
  lista.querySelectorAll('li').forEach(item => {
    item.addEventListener('click', () => {
      const index = item.getAttribute('data-index');
      abrirModal(service, index);
    });
  });
});

// Eventos de control
btnCerrar.addEventListener('click', () => modal.style.display = 'none');
btnSiguiente.addEventListener('click', siguienteCarta);
btnAnterior.addEventListener('click', anteriorCarta);

// Cerrar modal al clickear fuera
window.addEventListener('click', e => {
  if (e.target === modal) modal.style.display = 'none';
});
