document.addEventListener("DOMContentLoaded", function() {
  const nav = document.querySelector('nav');
  const menuLinks = document.querySelectorAll('nav ul li a');
  const headerHeight = document.querySelector('header').offsetHeight;

  const sections = [
    { id: 'inicio', element: document.querySelector('#inicio') },
    { id: 'servicios-de-turismo', element: document.querySelector('#servicios-de-turismo') },
    { id: 'alquileres', element: document.querySelector('#alquileres') },
    { id: 'viajes', element: document.querySelector('#viajes') },
    { id: 'nosotros-modern', element: document.querySelector('#nosotros-modern') },
    { id: 'contactos', element: document.querySelector('#contactos') }
  ];

  let lastValidSection = 'inicio';

  function getCurrentSection() {
    const scrollPosition = window.scrollY + headerHeight + 100;
    const isAtBottom = window.innerHeight + window.scrollY >= document.body.offsetHeight - 50;
    if (isAtBottom) return 'contactos';

    for (const section of sections) {
      const top = section.element.offsetTop;
      const bottom = top + section.element.offsetHeight;
      if (scrollPosition >= top && scrollPosition < bottom) {
        lastValidSection = section.id;
        return section.id;
      }
    }

    return lastValidSection;
  }

  function updateNav() {
    const currentSection = getCurrentSection();
    menuLinks.forEach(link => {
      link.classList.remove('active');
      if (link.getAttribute('href').substring(1) === currentSection) {
        link.classList.add('active');
      }
    });

    if (currentSection === 'contactos') {
      nav.classList.add('nav-black');
      nav.classList.remove('nav-transparent');
    } else {
      nav.classList.remove('nav-black');
      nav.classList.add('nav-transparent');
    }
  }

  menuLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (!target) return;

      const pos = this.getAttribute('href') === '#contactos'
        ? document.body.offsetHeight - window.innerHeight
        : target.offsetTop - headerHeight;

      window.scrollTo({ top: pos, behavior: 'smooth' });
    });
  });

  window.addEventListener('scroll', updateNav);
  window.addEventListener('resize', updateNav);
  updateNav();
});
