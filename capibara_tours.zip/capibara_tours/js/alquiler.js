// ======= IMÁGENES DEL MODAL =======
const imagenesAlquiler = [
  "./images/alquiler/alquiler_1.jpg",
  "./images/alquiler/alquiler_2.jpg",
  "./images/alquiler/alquiler_3.jpg",
  "./images/alquiler/alquiler_4.jpg",
  "./images/alquiler/alquiler_5.jpg",
  "./images/alquiler/alquiler_6.jpg",
  "./images/alquiler/alquiler_7.jpg",
  "./images/alquiler/alquiler_8.jpg",
  "./images/alquiler/alquiler_9.jpg",
];

let indiceActualAlquiler = 0;
let intervaloCambioRapido = null;
let intervaloAutomatico = null;

// ======= CARRUSEL =======
const track = document.getElementById("trackAlquiler");
let velocidad = 0.5;
let desplazamientoCarrusel = 0;

// Duplicar las imágenes para crear un efecto infinito continuo
function duplicarImagenesCarrusel() {
  const imagenesOriginales = track.innerHTML;
  track.innerHTML = imagenesOriginales + imagenesOriginales;
}

// Llamar a la función para duplicar las imágenes al cargar
duplicarImagenesCarrusel();

function moverCarrusel() {
  desplazamientoCarrusel += velocidad;
  
  // Cuando llegue al final del primer set de imágenes, reiniciar suavemente
  if (desplazamientoCarrusel >= track.scrollWidth / 2) {
    desplazamientoCarrusel = 0;
  }
  
  track.style.transform = `translateX(-${desplazamientoCarrusel}px)`;
  requestAnimationFrame(moverCarrusel);
}

// Iniciar el carrusel después de que las imágenes se hayan duplicado
setTimeout(() => {
  moverCarrusel();
}, 100);

// ======= FLECHAS CARRUSEL =======
const flechaIzq = document.getElementById("flechaIzq");
const flechaDer = document.getElementById("flechaDer");

function iniciarVelocidadRapida(dir) { velocidad = dir * 2.5; }
function detenerVelocidad() { velocidad = 1; }

["mouseenter","touchstart"].forEach(e => flechaIzq.addEventListener(e, () => iniciarVelocidadRapida(-1)));
["mouseleave","touchend"].forEach(e => flechaIzq.addEventListener(e, detenerVelocidad));
["mouseenter","touchstart"].forEach(e => flechaDer.addEventListener(e, () => iniciarVelocidadRapida(1)));
["mouseleave","touchend"].forEach(e => flechaDer.addEventListener(e, detenerVelocidad));

// ======= MODAL =======
function abrirGaleriaAlquiler(indice) {
  indiceActualAlquiler = indice;
  const modal = document.getElementById("modalAlquiler");
  const imagenModal = document.getElementById("imagenModalAlquiler");
  imagenModal.src = imagenesAlquiler[indice];
  modal.classList.add("mostrar");

  document.onkeydown = function(e) {
    if (e.key === "ArrowRight") cambiarImagenAlquiler(1);
    if (e.key === "ArrowLeft") cambiarImagenAlquiler(-1);
    if (e.key === "Escape") cerrarGaleriaAlquiler();
  };
}

function cambiarImagenAlquiler(direccion) {
  const imagenModal = document.getElementById("imagenModalAlquiler");
  imagenModal.classList.add("fade-out");
  setTimeout(() => {
    indiceActualAlquiler = (indiceActualAlquiler + direccion + imagenesAlquiler.length) % imagenesAlquiler.length;
    imagenModal.src = imagenesAlquiler[indiceActualAlquiler];
    imagenModal.classList.remove("fade-out");
    imagenModal.classList.add("fade-in");
    setTimeout(() => imagenModal.classList.remove("fade-in"), 400);
  }, 300);
}

function cerrarGaleriaAlquiler() {
  const modal = document.getElementById("modalAlquiler");
  modal.classList.remove("mostrar");
  clearInterval(intervaloCambioRapido);
  clearInterval(intervaloAutomatico);
  document.onkeydown = null;
}

// ======= TOQUE RÁPIDO EN FLECHAS MODAL =======
document.querySelectorAll(".flecha-izquierda, .flecha-derecha").forEach(flecha => {
  const dir = flecha.classList.contains("flecha-derecha") ? 1 : -1;
  flecha.addEventListener("mousedown", () => {
    intervaloCambioRapido = setInterval(() => cambiarImagenAlquiler(dir), 200);
  });
  flecha.addEventListener("mouseup", () => clearInterval(intervaloCambioRapido));
  flecha.addEventListener("mouseleave", () => clearInterval(intervaloCambioRapido));
  flecha.addEventListener("touchstart", () => {
    intervaloCambioRapido = setInterval(() => cambiarImagenAlquiler(dir), 200);
  });
  flecha.addEventListener("touchend", () => clearInterval(intervaloCambioRapido));
});