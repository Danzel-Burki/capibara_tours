document.addEventListener('DOMContentLoaded', function () {
  const modal = document.getElementById('modalServicios');
  const modalMedia = document.getElementById('modalMediaServicios');
  const modalDesc = document.getElementById('modalDescripcionServicios');
  const closeBtn = document.querySelector('.cerrar');
  const prevBtn = document.querySelector('.anterior');
  const nextBtn = document.querySelector('.siguiente');

  // === Datos de los servicios ===
  const servicios = {
    provincial: {
      images: [
        './images/servicios/servicio_2.jpg',  // Cataratas del Iguazú
        './images/servicios/servicio_8.jpg',  // Aeropuerto Iguazú
        './images/servicios/servicio_5.jpg',  // Ruinas San Ignacio
        './images/servicios/servicio_3.jpg',  // Minas de Wanda
        './images/servicios/servicio_10.jpg', // Hito Tres Fronteras
        './images/servicios/servicio_11.jpg'  // Duty Free
      ],
      descriptions: [
        'Cataratas del Iguazú - Maravilla natural de Misiones',
        'Aeropuerto Internacional Iguazú - Conexión con el mundo',
        'Ruinas de San Ignacio - Patrimonio histórico',
        'Minas de Wanda - Piedras preciosas naturales',
        'Hito Tres Fronteras - Encuentro de tres países',
        'Duty Free Shop - Compras sin impuestos'
      ]
    },

    internacional: {
      images: [
        './images/servicios/servicio_1.jpg',  // Cataratas Brasileras
        './images/servicios/servicio_7.jpg',  // Aeropuerto Brasil
        './images/servicios/servicio_6.jpg',  // Rueda Gigante
        './images/servicios/servicio_4.jpg',  // Parque Das Aves
        './images/servicios/servicio_15.jpg',  // Tour Ciudad del Este
        './images/servicios/servicio_12.jpg'  // Blue Park
      ],
      descriptions: [
        'Cataratas Brasileras - Vista panorámica desde Brasil',
        'Aeropuerto Internacional Brasil - Traslados rápidos y seguros',
        'Rueda Gigante - Vista espectacular de Foz do Iguaçu',
        'Parque Das Aves - Experiencia natural única',
        'Tour de un día - Compras en Ciudad del Este',
        'Blue Park - Aventura acuática para toda la familia'
      ]
    }
  };

  let currentService = null;
  let currentIndex = 0;

  // === EVENTOS EN LAS CARTAS ===
  document.querySelectorAll('.carta').forEach(carta => {
    carta.addEventListener('click', function () {
      currentService = this.getAttribute('data-service');
      currentIndex = parseInt(this.getAttribute('data-index'));
      updateModal();
      openModal();
    });
  });

  // === EVENTOS EN LAS LISTAS ===
  document.querySelectorAll('.lista-turismo li').forEach(item => {
    item.addEventListener('click', function () {
      const service = this.parentElement.getAttribute('data-service');
      const index = parseInt(this.getAttribute('data-index'));
      currentService = service;
      currentIndex = index;
      updateModal();
      openModal();
    });
  });

  // === ABRIR Y CERRAR MODAL ===
  function openModal() {
    modal.style.display = 'flex';
    modal.style.alignItems = 'center';
    modal.style.justifyContent = 'center';
    document.body.style.overflow = 'hidden';
  }

  function closeModal() {
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
  }

  closeBtn.addEventListener('click', closeModal);

  modal.addEventListener('click', e => {
    if (e.target === modal) closeModal();
  });

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && modal.style.display === 'flex') closeModal();
  });

  // === NAVEGACIÓN ENTRE IMÁGENES ===
  prevBtn.addEventListener('click', () => navigate(-1));
  nextBtn.addEventListener('click', () => navigate(1));

  function navigate(dir) {
    const service = servicios[currentService];
    currentIndex = (currentIndex + dir + service.images.length) % service.images.length;
    updateModal();
  }

  // === ACTUALIZAR CONTENIDO DEL MODAL ===
  function updateModal() {
    const service = servicios[currentService];
    if (!service) return;
    modalMedia.innerHTML = `
      <img src="${service.images[currentIndex]}" 
           alt="${service.descriptions[currentIndex]}" 
           class="modal-imagen">
    `;
    modalDesc.textContent = service.descriptions[currentIndex];
  }
});
