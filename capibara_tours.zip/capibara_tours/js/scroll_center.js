document.querySelectorAll('nav a').forEach(link => {
  link.addEventListener('click', function(e) {
    e.preventDefault();

    const targetId = this.getAttribute('href').substring(1);
    const section = document.getElementById(targetId);
    if (!section) return;

    // Busca título dentro de la sección, si no hay, usa la sección
    const title = section.querySelector('h1, h2, h3, h4') || section;

    // Calcula el scroll para centrar el título
    const rect = title.getBoundingClientRect();
    const scrollTop = window.pageYOffset + rect.top - (window.innerHeight / 2) + (title.offsetHeight / 2);

    // Limita el scroll dentro del documento
    const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
    const finalScroll = Math.min(Math.max(scrollTop, 0), maxScroll);

    window.scrollTo({
      top: finalScroll,
      behavior: 'smooth'
    });
  });
});
