// menu.js - Funcionalidad para el menú desplegable del logo y menú móvil

document.addEventListener('DOMContentLoaded', function() {
    // Elementos del DOM
    const headerLogo = document.getElementById('headerLogo');
    const menuDesplegable = document.getElementById('menuDesplegable');
    const menuToggle = document.getElementById('menuToggle');
    const mobileMenu = document.getElementById('mobileMenu');
    const overlay = document.getElementById('overlay');

    // ===== MENÚ DESPLEGABLE DEL LOGO (Desktop) =====
    if (headerLogo && menuDesplegable) {
        headerLogo.addEventListener('click', function(e) {
            e.stopPropagation();
            menuDesplegable.classList.toggle('active');
        });

        // Prevenir que el clic dentro del menú lo cierre
        menuDesplegable.addEventListener('click', function(e) {
            e.stopPropagation();
        });
    }

    // ===== MENÚ MÓVIL HAMBURGUESA =====
    if (menuToggle && mobileMenu && overlay) {
        menuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            mobileMenu.classList.toggle('active');
            overlay.classList.toggle('active');
            
            // Prevenir scroll del body cuando el menú está abierto
            document.body.style.overflow = mobileMenu.classList.contains('active') ? 'hidden' : '';
        });

        // Cerrar menú al hacer clic en el overlay
        overlay.addEventListener('click', function() {
            closeAllMenus();
        });

        // Cerrar menú al hacer clic en un enlace del menú móvil
        const mobileLinks = mobileMenu.querySelectorAll('a');
        mobileLinks.forEach(link => {
            link.addEventListener('click', function() {
                closeAllMenus();
            });
        });
    }

    // ===== CERRAR MENÚ AL HACER CLIC FUERA =====
    document.addEventListener('click', function() {
        if (menuDesplegable) {
            menuDesplegable.classList.remove('active');
        }
    });

    // ===== CERRAR MENÚ AL REDIMENSIONAR LA VENTANA =====
    window.addEventListener('resize', function() {
        if (window.innerWidth > 768) {
            closeAllMenus();
        }
    });

    // ===== FUNCIÓN PARA CERRAR TODOS LOS MENÚS =====
    function closeAllMenus() {
        // Cerrar menú desplegable
        if (menuDesplegable) {
            menuDesplegable.classList.remove('active');
        }
        
        // Cerrar menú móvil
        if (menuToggle) {
            menuToggle.classList.remove('active');
        }
        if (mobileMenu) {
            mobileMenu.classList.remove('active');
        }
        if (overlay) {
            overlay.classList.remove('active');
        }
        
        // Restaurar scroll del body
        document.body.style.overflow = '';
    }

    // ===== NAVEGACIÓN SUAVE PARA ANCLAS =====
    const menuLinks = document.querySelectorAll('a[href^="#"]');

    menuLinks.forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                // Cerrar todos los menús antes de navegar
                closeAllMenus();
                
                // Scroll suave hacia el elemento
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });

                // ===== RESALTAR EL ENLACE SELECCIONADO =====
                menuLinks.forEach(l => l.classList.remove('active'));
                this.classList.add('active');
            }
        });
    });

    // ===== RESALTAR SECCIÓN ACTIVA DURANTE EL SCROLL =====
    window.addEventListener('scroll', () => {
        const scrollPos = window.scrollY || window.pageYOffset;
        const sections = document.querySelectorAll('section[id]');
        let currentSection = '';

        // Encontrar la sección actualmente visible
        sections.forEach(section => {
            const sectionTop = section.offsetTop - 120; // Ajuste de offset
            const sectionHeight = section.offsetHeight;
            
            if (scrollPos >= sectionTop && scrollPos < sectionTop + sectionHeight) {
                currentSection = section.getAttribute('id');
            }
        });

        // Remover la clase active de todos los enlaces primero
        menuLinks.forEach(link => {
            link.classList.remove('active');
        });

        // Agregar la clase active al enlace correspondiente a la sección actual
        menuLinks.forEach(link => {
            const href = link.getAttribute('href');
            if (href === `#${currentSection}`) {
                link.classList.add('active');
            }
        });
    });

    // ===== CERRAR MENÚ AL PRESIONAR ESC =====
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeAllMenus();
        }
    });

    console.log('Menú cargado correctamente');
});