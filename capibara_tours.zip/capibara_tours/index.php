<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">

  <title>Capibara Tours R.A.</title>

  <!-- Estilos -->
  <link rel="stylesheet" href="./css/estilos.css" />

  <!-- FONT AWESOME 6 Free -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

  <!-- Favicon -->
  <link rel="icon" href="./images/logos/capi_.png" type="image/png" />

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />

  <!-- AOS Animations -->
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet" />
</head>

<body>
  <!-- ==================== FONDO DINÁMICO ==================== -->
  <div id="background-carousel" aria-hidden="true"></div>

  <!-- ==================== HEADER CON NAVEGACIÓN Y DECORACIÓN SVG ==================== -->
  <!-- Lianas fijas -->
  <div class="jungle-decor">
    <div class="image-wrapper left">
      <img src="./images/decoration/lianas1.png"
        alt="liana decorativa izquierda"
        class="liana liana-left">
    </div>

    <div class="image-wrapper right">
      <img src="./images/decoration/lianas2.png"
        alt="liana decorativa derehta"
        class="liana liana-right">
    </div>
  </div>

  <!-- Header -->
  <header>
    <!-- Logo -->
    <div class="header-logo">
      <img src="./images/logos/logo_RA.jpg" alt="Capibara Tours Logo">
    </div>

    <!-- Navegación principal - VISIBLE EN DESKTOP -->
    <nav>
      <ul>
        <li><a href="#inicio">Inicio</a></li>
        <li><a href="#servicios-de-turismo">Servicios de turismo</a></li>
        <li><a href="#alquileres">Alquileres</a></li>
        <li><a href="#viajes">Viajes Realizados</a></li>
        <li><a href="#nosotros-modern">Nosotros</a></li>
        <li><a href="#contactos">Contactos</a></li>
      </ul>
    </nav>

    <!-- Botón hamburguesa para móviles -->
    <div class="menu-toggle" id="menuToggle">
      <span></span>
      <span></span>
      <span></span>
    </div>
  </header>

  <!-- Menú móvil -->
  <div class="mobile-menu" id="mobileMenu">
    <ul>
      <li><a href="#inicio">Inicio</a></li>
      <li><a href="#servicios-de-turismo">Servicios de turismo</a></li>
      <li><a href="#alquileres">Alquileres</a></li>
      <li><a href="#viajes">Viajes Realizados</a></li>
      <li><a href="#nosotros-modern">Nosotros</a></li>
      <li><a href="#contactos">Contactos</a></li>
    </ul>
  </div>

  <!-- Overlay para menú móvil -->
  <div class="overlay" id="overlay"></div>




  <!-- ==================== SECCIÓN HERO ==================== -->
  <section id="inicio" class="hero" data-aos="fade-up">
    <div class="hero-background" id="heroBackground" aria-hidden="true">
      <div class="capa capa1"></div>
      <div class="capa capa2"></div>
    </div>

    <!-- Contenedor combinado -->
    <div class="hero-box">
      <!-- Columna izquierda: logo + redes -->
      <div class="hero-left">
        <div class="logo">
          <img src="./images/logos/logo.png" alt="Logo Capibara Tours">
        </div>
        <div class="social-icons">
          <a href="https://www.facebook.com/profile.php?id=61581843795666" target="_blank" rel="noopener noreferrer">
            <img src="https://img.icons8.com/color/48/000000/facebook-new.png" alt="Facebook" />
          </a>
          <a href="https://www.instagram.com/capibara.tours_iguazu/" target="_blank" rel="noopener noreferrer">
            <img src="https://img.icons8.com/color/48/000000/instagram-new.png" alt="Instagram" />
          </a>
          <a href="https://wa.me/3757503922" target="_blank" rel="noopener noreferrer">
            <img src="https://img.icons8.com/color/48/000000/whatsapp.png" alt="WhatsApp" />
          </a>
        </div>
      </div>

      <!-- Columna derecha: cartel bienvenida -->
      <div class="hero-right">
        <h1>
          <span class="bienvenidos">Bienvenidos a </span><br>
          <span class="nombre">CAPIBARA TOURS</span>
        </h1>
        <p>"Servicio profesional de transporte turístico en todo el país"</p>
      </div>
    </div>

    <!-- Imagen del capi dentro del hero -->
    <img src="./images/decoration/estrellas.png" alt="Tucán" class="tucan-flotante">

    <button class="arrow left" onclick="cambiarFondo(-1)" aria-label="Fondo anterior">&#10094;</button>
    <button class="arrow right" onclick="cambiarFondo(1)" aria-label="Fondo siguiente">&#10095;</button>
  </section>




  <!-- ==================== SECCIÓN SERVICIOS ==================== -->
  <section id="servicios-de-turismo" class="section servicios" data-aos="fade-left">
    <div class="container">
      <div class="contenido-servicios">
        <h2>SERVICIO DE TURISMO</h2>

        <div class="servicios-lista">

          <!-- SERVICIO 1 - Turismo Provincial -->
          <div class="servicio-card" data-aos="zoom-in">
            <img src="https://cdn-icons-png.flaticon.com/512/854/854878.png" alt="Turismo Provincial" class="icono-servicio">
            <h3>Turismo <br> Provincial</h3>

            <div class="baraja">
              <div class="carta" data-service="provincial" data-index="0">
                <img src="./images/servicios/servicio_1.jpg" alt="Cataratas del Iguazú">
              </div>
              <div class="carta" data-service="provincial" data-index="1">
                <img src="./images/servicios/servicio_8.jpg" alt="Aeropuerto Iguazú">
              </div>
              <div class="carta" data-service="provincial" data-index="2">
                <img src="./images/servicios/servicio_5.jpg" alt="Ruinas San Ignacio">
              </div>
              <div class="carta" data-service="provincial" data-index="3">
                <img src="./images/servicios/servicio_3.jpg" alt="Minas de Wanda">
              </div>
              <div class="carta" data-service="provincial" data-index="4">
                <img src="./images/servicios/servicio_10.jpg" alt="Hito Tres Fronteras">
              </div>
              <div class="carta" data-service="provincial" data-index="5">
                <img src="./images/servicios/servicio_11.jpg" alt="Duty Free">
              </div>
            </div>

            <ul class="lista-turismo" data-service="provincial">
              <li data-index="0"><i class="fas fa-water"></i> Cataratas del Iguazú</li>
              <li data-index="1"><i class="fas fa-map-marked-alt"></i> Aeropuerto Iguazú</li>
              <li data-index="2"><i class="fas fa-mountain"></i> Ruinas San Ignacio</li>
              <li data-index="3"><i class="fas fa-gem"></i> Minas de Wanda</li>
              <li data-index="4"><i class="fas fa-bus"></i> Hito Tres Fronteras</li>
              <li data-index="5"><i class="fas fa-store"></i> Duty Free</li>
            </ul>
          </div>

          <!-- SERVICIO 2 - Traslados Internacionales -->
          <div class="servicio-card" data-aos="zoom-in" data-aos-delay="100">
            <img src="https://cdn-icons-png.flaticon.com/512/201/201623.png" alt="Turismo Internacional" class="icono-servicio">
            <h3>Traslados <br> Internacionales</h3>

            <div class="baraja">
              <div class="carta" data-service="internacional" data-index="0">
                <img src="./images/servicios/servicio_2.jpg" alt="Cataratas Brasileras">
              </div>
              <div class="carta" data-service="internacional" data-index="1">
                <img src="./images/servicios/servicio_7.jpg" alt="Aeropuerto Brasil">
              </div>
              <div class="carta" data-service="internacional" data-index="2">
                <img src="./images/servicios/servicio_6.jpg" alt="Rueda Gigante">
              </div>
              <div class="carta" data-service="internacional" data-index="3">
                <img src="./images/servicios/servicio_4.jpg" alt="Parque Das Aves">
              </div>
              <div class="carta" data-service="internacional" data-index="4">
                <img src="./images/servicios/servicio_9.jpg" alt="NISSEI">
              </div>
              <div class="carta" data-service="internacional" data-index="5">
                <img src="./images/servicios/servicio_12.jpg" alt="Blue Park">
              </div>
              <div class="carta" data-service="internacional" data-index="5">
                <img src="./images/servicios/servicio_13.jpg" alt="New Zone">
              </div>
              <div class="carta" data-service="internacional" data-index="5">
                <img src="./images/servicios/servicio_14.jpg" alt="Cellshop">
              </div>
            </div>

            <ul class="lista-turismo" data-service="internacional">
              <li data-index="0"><i class="fas fa-water"></i> Cataratas Brasileras</li>
              <li data-index="1"><i class="fas fa-shopping-bag"></i> Aeropuerto Brasil</li>
              <li data-index="2"><i class="fas fa-plane-departure"></i> Rueda Gigante</li>
              <li data-index="3"><i class="fas fa-dove"></i> Parque Das Aves</li>
              <li data-index="4"><i class="fas fa-bus"></i> Tour de un día (Ciudad del Este)</li>
              <li data-index="5"><i class="fas fa-swimmer"></i> Blue Park</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>



  <!-- ==================== SECCIÓN DE ALQUILERES ==================== -->
  <section id="alquileres" class="section alquiler" data-aos="fade-left">
    <div class="container">
      <h2 class="titulo-alquiler">ALQUILERES</h2>

      <div class="carrusel">
        <div class="carrusel-track" id="trackAlquiler">
          <img src="./images/alquiler/alquiler_1.jpg" alt="Alojamiento 1" class="foto-alquiler" onclick="abrirGaleriaAlquiler(0)">
          <img src="./images/alquiler/alquiler_2.jpg" alt="Alojamiento 2" class="foto-alquiler" onclick="abrirGaleriaAlquiler(1)">
          <img src="./images/alquiler/alquiler_3.jpg" alt="Alojamiento 3" class="foto-alquiler" onclick="abrirGaleriaAlquiler(2)">
          <img src="./images/alquiler/alquiler_4.jpg" alt="Alojamiento 4" class="foto-alquiler" onclick="abrirGaleriaAlquiler(3)">
          <img src="./images/alquiler/alquiler_5.jpg" alt="Alojamiento 5" class="foto-alquiler" onclick="abrirGaleriaAlquiler(4)">
          <img src="./images/alquiler/alquiler_6.jpg" alt="Alojamiento 6" class="foto-alquiler" onclick="abrirGaleriaAlquiler(5)">
          <img src="./images/alquiler/alquiler_7.jpg" alt="Alojamiento 7" class="foto-alquiler" onclick="abrirGaleriaAlquiler(6)">
          <img src="./images/alquiler/alquiler_8.jpg" alt="Alojamiento 8" class="foto-alquiler" onclick="abrirGaleriaAlquiler(7)">
          <img src="./images/alquiler/alquiler_9.jpg" alt="Alojamiento 9" class="foto-alquiler" onclick="abrirGaleriaAlquiler(8)">
        </div>

        <!-- Flechas visibles -->
        <span class="flecha-carrusel izquierda" id="flechaIzq">&#10094;</span>
        <span class="flecha-carrusel derecha" id="flechaDer">&#10095;</span>
      </div>
    </div>

    <!-- Modal -->
    <div id="modalAlquiler" class="modal-alquiler">
      <span class="cerrar-alquiler" onclick="cerrarGaleriaAlquiler()">&times;</span>
      <span class="flecha-izquierda" onclick="cambiarImagenAlquiler(-1)">&#10094;</span>
      <img class="modal-contenido-alquiler" id="imagenModalAlquiler">
      <span class="flecha-derecha" onclick="cambiarImagenAlquiler(1)">&#10095;</span>
    </div>
  </section>



  <!-- ==================== MODAL SERVICIOS ==================== -->
  <div id="modalServicios" class="modal">
    <span class="cerrar">&times;</span>
    <div class="modal-contenido">
      <button class="anterior">&#10094;</button>
      <div id="modalMediaServicios"></div>
      <button class="siguiente">&#10095;</button>
    </div>
    <div id="modalDescripcionServicios"></div>
  </div>

  <!-- ==================== SECCIÓN GALERIA DE VIAJES ==================== -->
  <section id="viajes" class="section viajes" data-aos="fade-up">
    <div class="container">
      <div class="viajes-header">
        <h2 class="titulo-viajes">VIAJES REALIZADOS</h2>
        <p>"A lo largo de nuestra trayectoria, hemos brindado nuestros servicios a personas provenientes de países como Perú, Ecuador, Brasil, Argentina, Polonia y Croacia, acompañándolos en cada paso de su viaje y asegurando una experiencia segura, cómoda y confiable. Nos enorgullece haber contribuido a que tantos clientes de diferentes partes del mundo puedan trasladarse con tranquilidad y confianza."</p>
      </div>

      <!-- Grid principal con las primeras 6 fotos/videos -->
      <div class="viajes-grid" id="viajes-principales">
        <!-- 6 primeros viajes 
        <div class="viaje" data-aos="zoom-in" data-title="Helisul">
          <video src="./images/galeria_viajes_clientes/client_1.mp4" muted></video>
          <div class="descripcion">Helisul (Brasil)</div>
        </div> -->
        <div class="viaje" data-aos="zoom-in" data-aos-delay="100">
          <img src="./images/galeria_viajes_clientes/client_1.jpg" />
          <div class="descripcion">Flay Park, Pto. Iguazú (ARGENTINA)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="100">
          <img src="./images/galeria_viajes_clientes/client_2.jpg" />
          <div class="descripcion">Aeropuerto Cataratas del Iguazú IRG, (ARGENTINA)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="200">
          <img src="./images/galeria_viajes_clientes/client_3.jpg" />
          <div class="descripcion">Parque Nacional Iguazú (ARGENTINA)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="300">
          <img src="./images/galeria_viajes_clientes/client_4.jpg" />
          <div class="descripcion">Parque Das Aves (BRASIL)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="400">
          <img src="./images/galeria_viajes_clientes/client_5.jpg" />
          <div class="descripcion">Shopping Catuay (BRASIL)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="400">
          <img src="./images/galeria_viajes_clientes/client_6.jpg" />
          <div class="descripcion">Parque Nacional Iguazú (ARGENTINA)</div>
        </div>
      </div>

      <!-- Botón centrado debajo del grid principal -->
      <div class="contenedor-boton">
        <button id="btn-mostrar-mas" class="btn-mostrar-mas">Ver más viajes</button>
      </div> 

      <!-- Grid oculto debajo del botón -->
      <div id="viajes-ocultos" class="viajes-grid oculto">
        <div class="viaje" data-aos="zoom-in" data-aos-delay="100">
          <img src="./images/galeria_viajes_clientes/client_7.jpg" />
          <div class="descripcion">Represa de Itaipú (Frontera entre Paraguay y Brasi)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="100">
          <img src="./images/galeria_viajes_clientes/client_8.jpg" />
          <div class="descripcion">Yup Start, Foz do Iguaçu (BRASIL)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="100">
          <img src="./images/galeria_viajes_clientes/client_9.jpg" />
          <div class="descripcion">Yup Start, Foz do Iguaçu (BRASIL)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="100">
          <img src="./images/galeria_viajes_clientes/client_10.jpg" />
          <div class="descripcion">Aeropuerto Cataratas del Iguazú IRG, (ARGENTINA)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="100">
          <img src="./images/galeria_viajes_clientes/client_11.jpg" />
          <div class="descripcion">Icebar Iguazú, Puerto Iguazú (ARGENTINA)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="100">
          <img src="./images/galeria_viajes_clientes/client_12.jpg" />
          <div class="descripcion">Parque Nacional Iguazú (ARGENTINA)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="100">
          <img src="./images/galeria_viajes_clientes/client_13.jpg" />
          <div class="descripcion">Centro de Iguazú, (ARGENTINA)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="100">
          <img src="./images/galeria_viajes_clientes/client_14.jpg" />
          <div class="descripcion">Cataratas Foz do Iguaçu (BRASIL)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="100">
          <img src="./images/galeria_viajes_clientes/client_15.jpg" />
          <div class="descripcion">Cataratas Foz do Iguaçu (BRASIL)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="100">
          <img src="./images/galeria_viajes_clientes/client_16.jpg" />
          <div class="descripcion">Aeropuerto Foz do Iguaçu (BRASIL)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="100">
          <img src="./images/galeria_viajes_clientes/client_17.jpg" />
          <div class="descripcion">Parque Nacional Iguazú (ARGENTINA)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="100">
          <img src="./images/galeria_viajes_clientes/client_18.jpg" />
          <div class="descripcion">Restaurante la Rueda, Pto. Iguazú (ARGENTINA)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="100">
          <img src="./images/galeria_viajes_clientes/client_19.jpg" />
          <div class="descripcion">Represa de Itaipú (Frontera entre Paraguay y Brasi)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="100">
          <img src="./images/galeria_viajes_clientes/client_20.jpg" />
          <div class="descripcion">Parque Nacional Iguazú (ARGENTINA)</div>
        </div>
        <div class="viaje" data-aos="zoom-in" data-aos-delay="100">
          <img src="./images/galeria_viajes_clientes/client_21.jpg" />
          <div class="descripcion">Aeropuerto Foz do Iguaçu (BRASIL)</div>
        </div>
      </div>
    </div>
  </section>


  <!-- ==================== MODAL VIAJES ==================== -->
  <div id="modalViajes" class="modal">
    <span class="cerrar">&times;</span>
    <div class="modal-contenido">
      <button class="anterior">&#10094;</button>
      <div id="modalMediaViajes"></div>
      <button class="siguiente">&#10095;</button>
    </div>
    <div id="modalDescripcionViajes"></div>
  </div>


  <!-- ==================== SECCIÓN NOSOTROS ==================== -->
  <section id="nosotros-modern" data-aos="fade-up">
    <div class="nosotros-modern">
      <div class="nosotros-imagen">
        <img src="./images/fondo/perfil_oficial.jpg" />
      </div>
      <div class="nosotros-texto">
        <h2>¿QUIÉNES SOMOS?</h2>
        <p>
          <span class="rojo"> S</span> omos una empresa de traslados confiable y segura, con base en Puerto Iguazú, Misiones.
          Nos dedicamos a ofrecer un servicio de transporte cómodo, puntual y personalizado para quienes desean descubrir los encantos de la región: las majestuosas Cataratas del Iguazú, el Hito Tres Fronteras, y muchos otros destinos únicos.
          <BR>
          ✨ Viajá tranquilo, viajá con nosotros: tu aventura comienza aquí.
        </p>
      </div>
    </div>
  </section>





  <!-- ==================== FOOTER - CONTACTO ==================== -->
  <footer id="contactos" class="contactos" data-aos="fade-up">
    <div class="footer-container">
      <div class="footer-contacto">
        <h4>Contactos</h4>
        <p>📞 <a href="https://wa.me/3757503922" target="_blank">+54 9 3757 50 3922</a></p>
        <p>✉️ capibaratoursiguazu@gmail.com</p>
        <p>📍 Iguazú, Misiones, Argentina</p>
      </div>


      <div class="footer-redes">
        <h4>Redes Sociales</h4><br>

        <!-- Facebook -->
        <a href="https://www.facebook.com/profile.php?id=61579024276825"
          aria-label="Facebook"
          target="_blank"
          rel="noopener noreferrer">
          <img src="https://img.icons8.com/color/48/000000/facebook-new.png" alt="Facebook" />
        </a>

        <!-- Instagram -->
        <a href="https://www.instagram.com/traslados_diego_w._burki/"
          aria-label="Instagram"
          target="_blank"
          rel="noopener noreferrer">
          <img src="https://img.icons8.com/color/48/000000/instagram-new.png" alt="Instagram" />
        </a>

        <!-- WhatsApp -->
        <a href="https://wa.me/3757503922"
          aria-label="WhatsApp"
          target="_blank"
          rel="noopener noreferrer">
          <img src="https://img.icons8.com/color/48/000000/whatsapp.png" alt="WhatsApp" />
        </a>
      </div>


      <div class="footer-pagos">
        <h4>Medios de Pago</h4>
        <div class="pagos-iconos">
          <img src="https://img.icons8.com/color/48/000000/visa.png" alt="Visa" />
          <img src="https://img.icons8.com/color/48/000000/mastercard-logo.png" alt="MasterCard" />
          <img src="https://img.icons8.com/color/48/000000/cash-in-hand.png" alt="Efectivo" />
          <img src="https://img.icons8.com/color/48/000000/qr-code.png" alt="QR" />
        </div>
      </div>
    </div>

    <div class="footer-content">
      <div class="footer-logo">
        <img src="./images/logos/capi_.png" alt="Capibara_tours">
      </div>

      <div class="footer-creditos">
        <p>&copy; 2025 Capibara Tours R.A. Todos los derechos reservados.
          Desarrollado por Danzel Blotz Burki</p>
      </div>
    </div>

  </footer>

  <!-- ==================== RESEÑAS FLOTANTE ==================== -->
  <a href="https://www.trustpilot.com/review/capibara-tours-iguazu.com.ar"
    target="_blank"
    rel="noopener"
    id="reseñasBtn"
    aria-label="Ver Reseñas">
    <div class="reseñas-texto">Para ver reseñas</div>
    <img src="./images//decoration/reseñas.ico" alt="Ver Reseñas">
  </a>


  <!-- ==================== WHATSAPP FLOTANTE ==================== -->
  <a href="https://wa.me/3757503922" target="_blank" id="whatsappBtn" aria-label="Contactar por WhatsApp">
    <img src="https://cdn-icons-png.flaticon.com/512/733/733585.png" alt="WhatsApp">
  </a>



  <!-- ==================== BOTÓN VOLVER ARRIBA ==================== -->
  <button id="scrollTopBtn" title="Volver arriba" aria-label="Volver arriba">
    &#11014;
  </button>



  <!-- ==================== SCRIPTS ==================== -->
  <script src="./js/background.js"></script>
  <script src="./js/hero_fondo.js"></script>
  <script src="./js/scroll_menu.js"></script>
  <script src="./js/scroll_top.js"></script>
  <script src="./js/servicios.js"></script>
  <script src="./js/observador.js"></script>
  <script src="./js/bt_ver_mas-menos.js"></script>
  <script src="./js/scroll_center.js"></script>
  <script src="./js/header_compressed.js"></script>
  <script src="./js/scroll_spy.js"></script>
  <script src="./js/modal_galeria.js"></script>
  <script src="./js/modal_servicios.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
  <script src="./js/modal_lista_servicios_pn.js"></script>
  <script src="./js/burger.js"></script>
  <script src="./js/alquiler.js"></script>


  <script>
    AOS.init();
  </script>

</body>

</html>